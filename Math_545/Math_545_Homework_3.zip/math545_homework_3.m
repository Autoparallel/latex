% Problem 2
% Fourier Series for f(x)= -1 x<0; f(x)=1 x>0.

syms x n
f3 = symsum((4/((2*n+1)*pi))*sin((2*n+1)*x),n,0,3);
f6 = symsum((4/((2*n+1)*pi))*sin((2*n+1)*x),n,0,6);
f15 = symsum((4/((2*n+1)*pi))*sin((2*n+1)*x),n,0,15);
f30 = symsum((4/((2*n+1)*pi))*sin((2*n+1)*x),n,0,30);

%To plot
fplot(f30, [-3*pi 3*pi])

%for fun
%f = symsum((4/((2*n+1)*pi))*sin((2*n+1)*x),n,0,300);
%fplot(f, [-pi pi])