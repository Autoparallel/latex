syms n x t

%Part (a)
u = 6*exp(-36*pi^2*t)*sin(9*pi*x);

%Part (b)
u = 3*exp(-pi^2*t)*sin(pi*x)-exp(-9*pi^2*t)*sin(3*pi*x);

%Part (c)
u = symsum((8*(2*n+1))/(pi*((2*n+1)^2-4))*exp(-(2*n+1)^2*pi^2*t)*sin((2*n+1)*pi*x),n,1,500);

%Part (d)
u = symsum((2+2*cos(n*pi/2)-4*cos(n*pi))/(n*pi)*exp(-n^2*pi^2*t)*sin(n*pi*x),n,1,500);

%Plot
fsurf(u, [0 1/16 0 1])
