% Math 545 Homework 6 Problems

% Problem 2
syms u(x,t) n

A_n = 4*sin(n*pi/8)^2/(n*pi);
u(x,t) = symsum(A_n*cos(n*pi*t/4)*sin(n*pi*x/4), n,1,100);
fplot(u(x,20), [0 4])