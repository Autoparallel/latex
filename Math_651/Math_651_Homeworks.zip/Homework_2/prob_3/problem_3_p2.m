%% Problem 3

% Part 2
% Cubic spline approximation p^h for f(x) using N points on [0,1]

numpoints = 10000;
x = linspace(0,1,numpoints);
f = @(x) x.*exp(x)-1;

total_runs = 99;
xstars = zeros(1,total_runs-1);
nums = zeros(1,total_runs-1);
for i = 2 : total_runs
    nums(1,i) = i;
end

for N = 2 : total_runs+1
    mes_y = zeros(N,1);
    mes_x = zeros(N,1);
    mes_x(:,1) = linspace(0,1,N); % Compute equidistant "measured" x_i
    h_k = 1/N; % interval lengths

    for i = 1 : N
        mes_y(i,1) = f(mes_x(i,1));
    end

    % A Matrix coeffs
    a = zeros(N,N);
    for i = 2 : N-1
        for j = 2 : N-1
            if i==j
                a(i,j) = 2*( (1/(mes_x(i+1,1)-mes_x(i,1)))...
                + (1/(mes_x(i,1)-mes_x(i-1,1))) );
            elseif abs(i-j)>=2
                a(i,j) = 0;
            else
                a(i,j) = 1/(mes_x(i,1)-mes_x(i-1,1));
            end
        end
    end
    a(1,1) = 2/(mes_x(2,1)-mes_x(1,1));
    a(1,2) = 1/(mes_x(2,1)-mes_x(1,1));
    a(2,1) = a(1,2);
    a(N,N-1) = 1/(mes_x(N,1)-mes_x(N-1,1));
    a(N-1,N) = a(N,N-1);
    a(N,N) = 2/(mes_x(N,1)-mes_x(N-1,1));

    % B vector
    b = zeros(N,1);
    b(1,1) = 3*( (mes_y(2,1)-mes_y(1,1))/((mes_x(2,1)-mes_x(1,1))^2) );
    b(N,1) = 3*( (mes_y(N,1)-mes_y(N-1,1))/((mes_x(N,1)-mes_x(N-1,1))^2) );
    for i = 2 : N-1
        b(i,1) = 3*( (mes_y(i,1)-mes_y(i-1,1))/((mes_x(i,1)...
        -mes_x(i-1,1))^2)+(mes_y(i+1,1)-mes_y(i,1))/((mes_x(i+1,1)-mes_x(i,1))^2) );
    end
    kappa = zeros(N,1);
    kappa(:,1) = linsolve(a(:,:),b(:,1));

    t = zeros(N,1);

    alpha = zeros(N,1);
    beta = zeros(N,1);
    counter = 1;
    q = zeros(1,numpoints);
    for k=1 : numpoints
       if (mes_x(counter)<=x(k)) && (x(k)<=mes_x(counter+1)) 
       %check if x in correct region
            t(counter,1) = (x(k)-mes_x(counter,1))/(mes_x(counter+1,1)...
            -mes_x(counter,1));
            
            alpha(counter,1) = kappa(counter,1)*(mes_x(counter+1,1)...
            -mes_x(counter,1))-(mes_y(counter+1,1)-mes_y(counter,1));
            
            beta(counter,1) = -kappa(counter+1,1)*(mes_x(counter+1,1)...
            -mes_x(counter,1))+(mes_y(counter+1,1)-mes_y(counter,1));
            
            q(1,k) = mes_y(counter,1)*(1-t(counter,1)) ...
            + mes_y(counter+1,1)*t(counter,1)+t(counter,1)*(1-t(counter,1))...
            *((1-t(counter,1))*alpha(counter,1)...
            +t(counter,1)*beta(counter,1));
       else
           q(1,k) = mes_y(counter+1,1);
           counter = counter+1;
       end
    end

    df = zeros(1,numpoints-1);
    for k = 1 : numpoints-1
        df(1,k) = (q(1,k+1)-q(1,k))/(x(k+1)-x(k));
    end

    its = 50; % Number of iterates for NM
    iterations = zeros(its-1,1);
    for k = 1 : its-1
        iterations(k,1) = k;
    end

    x_star = zeros(its,1);

    x_star(1,1) = 0.5; % initial guess

    for k = 1 : its-1
        convert = floor(x_star(k,1)*numpoints);
        x_star(k+1,1) = x_star(k,1)-q(convert)/df(convert);
    end
    xstars(1,N-1) = x_star(its,1);
end

figure
log_dif_xstars = zeros(1,total_runs-1);
for i = 1 : total_runs
    log_dif_xstars(1,i) = log(abs(xstars(1,i)-0.567143));
end
plot(nums(1,:),log_dif_xstars(1,:))
title(['Log(|x^{*N}-x^*|) for N=' num2str(N)])
xlabel('N') 
ylabel('Log(|x^{*N}-x^*|')

% figure
% plot(x,q,x,f(x));
% title(['Cubic Spline Approx., With N = ' num2str(N)])
% legend({'xe^x-1', 'ph(x)'},'Location','Northeast')
% xlabel('x') 
% ylabel('ph(x)')







