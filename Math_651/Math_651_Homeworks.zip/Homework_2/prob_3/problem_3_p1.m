%% Problem 3

% Part 1

% Newton's Method (NM) to compute the root of f(x)=x*exp(x)-1.
% x_{k+1} = x_k - f(x_k)/f'(x_k)
numpoints = 10000;
x = linspace(0,1,numpoints);

its = 6; % Number of iterates for NM
iterations = zeros(its-1,1);
for k = 1 : its-1
    iterations(k,1) = k;
end

x_star = zeros(its,1);

x_star(1,1) = 0.5; % initial guess
f = @(x) x.*exp(x)-1;

df = @(x) exp(x).*(x+1);

for k = 1 : its-1
    x_star(k+1,1) = x_star(k,1)-f(x_star(k,1))/df(x_star(k,1));
end

% Compute differences between x_star values

diffs_x_star = zeros(its-1,1); %log_10 of differences to see if it hits -6
for i = 1 : its-1
    diffs_x_star(i,1) = log(x_star(i+1,1)-x_star(i,1))/log(10);
end

plot(iterations(:,1),diffs_x_star(:,1));