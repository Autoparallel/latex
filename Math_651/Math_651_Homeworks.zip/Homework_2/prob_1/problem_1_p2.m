%% Problem 1
% Part 2

plotpoints = 10000;
a=-1;
b=1;
x = linspace(a,b,plotpoints);
f = zeros(1,plotpoints);

total_runs = 30;
maxdiff = zeros(1,total_runs);
nums = zeros(1,total_runs);

for i = 1 : total_runs
    nums(1,i) = i;
end

for N = 1 : total_runs
    mes_x = zeros(N,1);
    % Compute Chebyshev roots
    for n=1:N
        mes_x(n,1) = cos((2*n-1)*pi/(2*N)); % on [-1,1]
    end
    mes_y = zeros(N,1);

    for i=1:N
        mes_y(i,1) = 0.002*(rand - .5); % noisy y_i
    end

    Mat = zeros(N,N);
    coeffs = zeros(N,1);

    for i=1:N % Row
        for j=1:N % Col
            if j==1
                Mat(i,j) = 1;
            else
                Mat(i,j) = mes_x(i,1)^(j-1);
            end
        end
    end

    % Solve Mat * coeffs = mes_y
    coeffs(:,1) = linsolve(Mat,mes_y(:,1)); 
    p = zeros(1,plotpoints);
    for i=1:N
        for j=1:plotpoints
            p(1,j) = p(1,j)+coeffs(i,1)*x(1,j)^(i-1);
        end
    end
    diff = abs(p-f); % difference
    maxdiff(1,N) = max(diff);
end

figure
subplot(2,1,1)
plot(x,f(1,:),x,p)
title(['Poly. Approx., Rand x_i, Chebyshev, With N = ' num2str(N)])
legend({'0 function', 'p_{N-1}(x)'},'Location','Northeast')
xlabel('x') 
ylabel('p_{N-1}(x)')
subplot(2,1,2)
plot(nums(1,:),maxdiff(1,:))
title(['Error in p_{N_1}(x) '])
xlabel('N') 
ylabel('Error')