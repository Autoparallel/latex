%% Problem 2
% Part 2
% Single interval, replace each by half adaptively f(x)=sin(1/x)

plotpoints = 1000000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);

N=2; %starting point
total_runs = 129;

maxdiff = zeros(1,total_runs);
nums = zeros(1,total_runs);
for i = 1 : total_runs
    nums(1,i) = i;
end

mes_x = zeros(N,1);
mes_x(:,1) = linspace(a,b,N);
mes_y = zeros(N,1);

for i=1:N
    mes_y(i,1) = sin(1/mes_x(i,1)); % Compute y_i
end

f = sin(1./x);

for num = 1 : total_runs
    counter = 1;
    
    y = zeros(1,plotpoints);
    for k=1:plotpoints
       if (mes_x(counter,1)<=x(k)) && (x(k)<=mes_x(counter+1,1))
           %check if x in correct region
           m = (mes_y(counter+1,1)-mes_y(counter,1))/ ...
           (mes_x(counter+1,1)-mes_x(counter,1));
           y(1,k) = m*(x(k)-mes_x(counter))+mes_y(counter);
       else
           y(1,k) = mes_y(counter+1,1);
           counter = counter+1;
       end
    end
    diff = abs(y-f);
    maxdiff(1,num) = max(diff);
    % Find index then x value for maximum difference
    [M,I] = max(diff);
    what_interval = 1;
    for i = 1 : plotpoints
        if (mes_x(what_interval,1)<=x(I)) && (x(I)<=mes_x(what_interval+1,1))
            %create new x midway and add to mes_x
            newx = mes_x(what_interval,1)+.5*(mes_x(what_interval+1,1)...
            -mes_x(what_interval,1));
            break %leave the loop when this happens
        else
            what_interval = what_interval+1;
        end
    end
    mes_x(N+1,1) = newx;
    mes_x(:,1) = sort(mes_x(:,1));
    N = N+1;
    for i = 1 : N
        mes_y(i,1) = sin(1/mes_x(i,1));
    end
    if maxdiff(1,num)< 10^(-3)
        num
        break
    end
end


figure
subplot(2,1,1)
plot(x,f,x,y(1,:)) %plots the last approx
title(['Adaptive Piecewise Linear Approx. With NumSplits = ' num2str(num)])
legend({'f(x) = sin(1/x)', 'p(x)'},'Location','Northeast')
xlabel('x') 
ylabel('ph(x)')
subplot(2,1,2)
plot(nums(1,:),maxdiff(1,:))
title(['Error in ph(x) '])
xlabel('N') 
ylabel('Error')