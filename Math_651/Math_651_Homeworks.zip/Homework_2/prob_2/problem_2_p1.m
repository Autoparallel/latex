%% Problem 2
% Part 1
% Single interval, replace each by half f(x)=sin(1/x)

plotpoints = 1000000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);
f = sin(1./x);

total_runs = 129;

maxdiff = zeros(1,total_runs);
nums = zeros(1,total_runs);
for i = 1 : total_runs
    nums(1,i) = i;
end

for num = 1 : total_runs
    N = 2*num;
    mes_x = zeros(N,1);
    mes_x(:,1) = linspace(a,b,N);
    mes_y = zeros(N,1);

    for i=1:N
        mes_y(i,1) = sin(1/mes_x(i,1)); % Compute y_i
    end

    counter = 1;
    y = zeros(1,plotpoints);
    for k=1:plotpoints
       if (mes_x(counter,1)<=x(k)) && (x(k)<=mes_x(counter+1,1)) 
       %check if x in correct region
           m = (mes_y(counter+1,1)-mes_y(counter,1))/...
           (mes_x(counter+1,1)-mes_x(counter,1));
           
           y(1,k) = m*(x(k)-mes_x(counter))+mes_y(counter);
       else
           y(1,k) = mes_y(counter+1,1);
           counter = counter+1;
       end
    end
    diff = abs(y-f);
    maxdiff(1,num) = max(abs(y-f));
    if maxdiff(1,num)< 10^(-3)
        break
    end
end


figure
subplot(2,1,1)
plot(x,f,x,y(1,:)) %plots the last approx
title(['Piecewise Linear Approx. With NumSplits = ' num2str(num)])
legend({'f(x) = sin(1/x)', 'ph(x)'},'Location','Northeast')
xlabel('x') 
ylabel('ph(x)')
subplot(2,1,2)
plot(nums(1,:),maxdiff(1,:))
title(['Error in ph(x) '])
xlabel('N') 
ylabel('Error')