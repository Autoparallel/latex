%% Problem 3
% Explicit Euler Method

% ISS Orbit time ~ 5520 seconds

altitude = 408000+6371000; %in meters
speed = 7660; %in meters/sec

T_orbit = 5560.5369451;

% Error plotting
err = zeros(5,1);
nums = zeros(5,1);
stepsize_vec = zeros(5,1);

for i = 1 : 5
   nums(i,1) = T_orbit/(10^i); 
end

for count = 1 : 4
    h = nums(count,1);
    steps = floor(100*T_orbit/h);
    stepsize_vec(count,1) = h;
    % Solution vector
    % 1,2 are position x and y
    % 3,4 are velocity vx and vy
    vec = zeros(4,steps);
    % Initially all altitude in x-direction
    vec(1,1) = altitude; 
    vec(2,1) = 0;
    % Initially all velocity in y-direction
    vec(3,1) = 0;
    vec(4,1) = speed;
    for i = 1:steps-1   
       % Explicit Euler Step
       vec(1:2,i+1) = vec(1:2,i)+h*vec(3:4,i);
       vec(3:4,i+1) = vec(3:4,i)+h*F(vec(1,i),...
       vec(2,i));
    end
    
    err(count,1) = sqrt((vec(1,steps)-vec(1,1))^2+...
        (vec(2,steps)-vec(2,1))^2);
end

t = linspace(0,2*pi,1000);
earth = zeros(2,1000);
for i = 1 : 1000
    earth(1,i) = 6371000*cos(2*pi*t(i));
    earth(2,i) = 6371000*sin(2*pi*t(i));
end

% Plot error |x(T_100orbits) - x_N|
loglog(stepsize_vec(:,1),err(:,1));
title('ISS Trajectory: Explicit Euler Method Closed Orbit Error');
legend({'Error'},'Location','Northeast')
xlabel('h') 