function [output] = F(x,y)

output = zeros(2,1);

output(1,1) = -(6371000)^2*9.81*(x/sqrt(x^2+y^2))*(1/(x^2+y^2));
output(2,1) = -(6371000)^2*9.81*(y/sqrt(x^2+y^2))*(1/(x^2+y^2));
end

