%% Problem 3
% Explicit Euler Method

% ISS Orbit time ~ 5520 seconds

altitude = 408000+6371000; %in meters
speed = 7660; %in meters/sec

h = 500;
steps = 100;

% Solution vector
% 1,2 are position x and y
% 3,4 are velocity vx and vy
vec = zeros(4,steps);
% Initially all altitude in x-direction
vec(1,1) = altitude; 
vec(2,1) = 0;
% Initially all velocity in y-direction
vec(3,1) = 0;
vec(4,1) = speed;

for i = 1:steps-1   
   % Explicit Euler Step
   vec(1:2,i+1) = vec(1:2,i)+h*vec(3:4,i);
   vec(3:4,i+1) = vec(3:4,i)+h*F(vec(1,i),...
   vec(2,i));
end

t = linspace(0,2*pi,1000);
earth = zeros(2,1000);
for i = 1 : 1000
    earth(1,i) = 6371000*cos(2*pi*t(i));
    earth(2,i) = 6371000*sin(2*pi*t(i));
end

plot(vec(1,:),vec(2,:),earth(1,:),earth(2,:));
title(['ISS Trajectory: Explicit Euler Method with h=',num2str(h), ', seconds=',num2str(steps*h)]);
legend({'Trajectory'},'Location','Northeast')
xlabel('x') 
ylabel('y')