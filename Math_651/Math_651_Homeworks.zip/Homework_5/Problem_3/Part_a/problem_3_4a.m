%% Problem 3
% Fourth Order Runge Kutta Method

% ISS Orbit time ~ 5520 seconds

altitude = 408000+6371000; %in meters
speed = 7660; %in meters/sec

h = 1;
steps = 10000;

% Solution vector
% 1,2 are position x and y
% 3,4 are velocity vx and vy
vec = zeros(4,steps);
% Initially all altitude in x-direction
vec(1,1) = altitude; 
vec(2,1) = 0;
% Initially all velocity in y-direction
vec(3,1) = 0;
vec(4,1) = speed;

% F1-F4
F1 = zeros(4,1);
F2 = zeros(4,1);
F3 = zeros(4,1);
F4 = zeros(4,1);

%Solve the equation
for i = 1 : steps-1
    
    F1(1:2,1) = h*vec(3:4,i);
    F1(3:4,1) = h*F(vec(1,i),vec(2,i));
    
    F2(1:2,1) = h*vec(3:4,i);
    F2(3:4,1) = h*F(vec(1,i)+.5*F1(1,1),vec(2,i)+.5*F1(2,1));
    
    F3(1:2,1) = h*vec(3:4,i);
    F3(3:4,1) = h*F(vec(1,i)+.5*F2(1,1),vec(2,i)+.5*F2(2,1));    
    
    F4(1:2,1) = h*vec(3:4,i);
    F4(3:4,1) = h*F(vec(1,i)+F3(1,1),vec(2,i)+F3(2,1));
    
    
    vec(:,i+1) = vec(:,i)+(1/6)*(F1(:,1)+2*F2(:,1)+2*F3(:,1)+F4(:,1));
end


t = linspace(0,2*pi,1000);
earth = zeros(2,1000);
for i = 1 : 1000
    earth(1,i) = 6371000*cos(2*pi*t(i));
    earth(2,i) = 6371000*sin(2*pi*t(i));
end

plot(vec(1,:),vec(2,:),earth(1,:),earth(2,:));
title(['ISS Trajectory: Fourth Order R-K Method with h=',num2str(h),...
    ', seconds=',num2str(steps*h)]);
legend({'Trajectory'},'Location','Northeast')
xlabel('x') 
ylabel('y')