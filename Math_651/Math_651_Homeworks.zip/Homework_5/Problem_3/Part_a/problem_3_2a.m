%% Problem 3
% Implicit Euler Method

% ISS Orbit time ~ 5520 seconds

altitude = 408000+6371000; %in meters
speed = 7660; %in meters/sec

% h = 20, steps = 340, start to see error
h = 1;
steps = 100000; 

% Number of Newton iterations
Newton_Steps = 10;

% Solution vector
% 1,2 are position
% 3,4 are velocity
vec = zeros(4,steps,Newton_Steps);
% Initially all altitude in x-direction
vec(1,1,:) = altitude; 
vec(2,1,:) = 0;
% Initially all velocity in y-direction
vec(3,1,:) = 0;
vec(4,1,:) = speed;

% G function to find zero for
G = zeros(4,1);

% Jacobian
Jac= zeros(4,4);

for i = 1 : steps-1       
   % Do explicit Euler step for the guess
   vec(1:2,i+1,1) = vec(1:2,i,Newton_Steps)+h*vec(3:4,i,Newton_Steps);
   vec(3:4,i+1,1) = vec(3:4,i,Newton_Steps)+h*F(vec(1,i,Newton_Steps),...
       vec(2,i,Newton_Steps));
   
   for k = 1 : Newton_Steps-1
       % Compute G = -x_{i+1}+x_i +hf(t_{i+1},x_{i+1})
       G(1:2,1) = -vec(1:2,i+1,k)+vec(1:2,i,Newton_Steps)+...
           h*vec(3:4,i+1,k);
       G(3:4,1) = -vec(3:4,i+1,k)+vec(3:4,i,Newton_Steps)+...
           h*F(vec(1,i+1,k),vec(2,i+1,k));
       
       Jac = J(vec(1,i+1,k),vec(2,i+1,k),h); %compute Jacobian of G
       
       vec(:,i+1,k+1) = vec(:,i+1,k)-Jac\G;
   end
end

t = linspace(0,2*pi,1000);
earth = zeros(2,1000);
for i = 1 : 1000
    earth(1,i) = 6371000*cos(2*pi*t(i));
    earth(2,i) = 6371000*sin(2*pi*t(i));
end

plot(vec(1,:,Newton_Steps),vec(2,:,Newton_Steps),earth(1,:),earth(2,:));
title(['ISS Trajectory: Implicit Euler Method with h=',num2str(h), ', seconds=',num2str(steps*h)]);
legend({'Trajectory', 'Earth'},'Location','Northeast')
xlabel('x') 
ylabel('y')