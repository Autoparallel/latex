%% Problem 2
% Fourth Order Runge-Kutta, h=2^(-n)


x_at_1 = (1+exp(-1/3))*exp(1)-1;
x_0 = 1;

err1 = zeros(10,1);
step_size = zeros(10,1);

for n = 1 : 10
    Delta_t = 2^(-n);
    step_size(n,1) = Delta_t;
    a = 0;
    b = 1;
    num_steps = 1+(b-a)/Delta_t;
    t_vals = linspace(a,b,1+(b-a)/Delta_t);
    approx_x = zeros(num_steps,1);
    
    %Initialize approx_x
    approx_x(1,1) = x_0;
    
    %Solve the equation
    curr_t = 0;
    for i = 2 : num_steps
        F1 = Delta_t*f(curr_t, approx_x(i-1,1));
        F2 = Delta_t*f(curr_t+.5*Delta_t, approx_x(i-1,1)+F1/2);
        F3 = Delta_t*f(curr_t+.5*Delta_t, approx_x(i-1,1)+F2/2);
        F4 = Delta_t*f(curr_t+Delta_t, approx_x(i-1,1)+F3);
        approx_x(i,1) = approx_x(i-1,1)+(1/6)*(F1+2*F2+2*F3+F4);
        curr_t = curr_t + Delta_t;
        if curr_t > 1
            curr_t = 1;
        end
    end
    err1(n,1) = abs(approx_x(num_steps,1)-x_at_1);
end

loglog(step_size(:,1),err1(:,1),step_size(:,1),step_size(:,1));
title(['Error in RK4 Method with h=2^{-n}'])
legend({'Error in x(1)','O(h)'},'Location','Northeast')
xlabel('Step size') 
ylabel('Error')