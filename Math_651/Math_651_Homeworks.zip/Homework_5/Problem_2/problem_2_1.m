%% Problem 2
% Explicit Euler Method, h=2^(-n)


x_at_1 = (1+exp(-1/3))*exp(1)-1;
x_0 = 1;

err1 = zeros(10,1);
step_size = zeros(10,1);

for n = 1 : 10
    curr_t = 0;
    Delta_t = 2^(-n);
    step_size(n,1) = Delta_t;
    a = 0;
    b = 1;
    num_steps = 1+(b-a)/Delta_t;
    t_vals = linspace(a,b,1+(b-a)/Delta_t);
    approx_x = zeros(num_steps,1);
    
    %Initialize approx_x
    approx_x(1,1) = x_0;
    
    %Solve the equation
    for i = 2 : num_steps
        if curr_t < 1/3
            approx_x(i,1) = approx_x(i-1,1)+Delta_t*approx_x(i-1,1); %before t=1/3
            curr_t = curr_t+Delta_t;
        else
            approx_x(i,1) = approx_x(i-1,1)+Delta_t*(approx_x(i-1,1)+1); %after t=1/3
            curr_t = curr_t+Delta_t;
            if curr_t > 1
                curr_t = 1;
            end
        end
    end
    err1(n,1) = abs(approx_x(num_steps,1)-x_at_1);
end

loglog(step_size(:,1),err1(:,1),step_size(:,1),step_size(:,1));
title(['Error in Explicit Euler Method with h=2^{-n}'])
legend({'Error in x(1)','O(h)'},'Location','Northeast')
xlabel('Step size') 
ylabel('Error')