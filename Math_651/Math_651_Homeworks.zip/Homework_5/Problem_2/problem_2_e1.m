%% Problem 2
% Explicit Euler Method with new f, h=2^(-n)

% These are new
x_at_1 = ((exp(.5)+1)/exp(.5))*exp(1)-1.5;
x_0 = 1;

err1 = zeros(10,1);
step_size = zeros(10,1);

for n = 1 : 10
    h = 2^(-n);
    step_size(n,1) = h;
    a = 0;
    b = 1;
    num_steps = 1+(b-a)/h;
    t_vals = linspace(a,b,1+(b-a)/h);
    approx_x = zeros(num_steps,1);
    
    %Initialize approx_x
    approx_x(1,1) = x_0;
    
    %Solve the equation
    curr_t = 0;
    for i = 1 : num_steps-1
        if curr_t < 1
            approx_x(i+1,1) = approx_x(i,1) +...
                h*f_new(curr_t,approx_x(i,1));
            curr_t = curr_t + h;
        else
            curr_t = 1;
        end
    end
    err1(n,1) = abs(approx_x(num_steps,1)-x_at_1);
end

loglog(step_size(:,1),err1(:,1),step_size(:,1),step_size(:,1));
title(['Error in Explicit Euler Method with h=2^{-n} and new f'])
legend({'Error in x(1)','O(h)'},'Location','Northeast')
xlabel('Step size') 
ylabel('Error')