%% Problem 1
% Part iv: Two Point Gauss Rule

plotpoints = 100000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);
f = sin(1./x);



% How many intervals to stop at
max_intervals = 10000; 
% Store integral for each amount of intervals
int_val = zeros(max_intervals,1);
err_val = zeros(max_intervals,1);
nums = zeros(max_intervals,1);

for i = 1 : max_intervals
    nums(i,1) = 2*i;
end

for K = 1 : max_intervals
    % K is the current number of intervals
    h = (b-a)/K; % Size of interval
    
    endpoint_x = zeros(K+1,1);
    endpoint_x(:,1) = linspace(a,b,K+1);
    
    gauss_x = zeros(2*K,1);
    gauss_y = zeros(2*K,1);
    
    % Compute Gauss points
    i = 1;
    int_count1 = 1;
    while i < 2*K
        gauss_x(i,1) = -(h/2)*(1/sqrt(3))+.5*(endpoint_x(int_count1,1)+endpoint_x(int_count1+1,1));
        gauss_x(i+1,1) = (h/2)*(1/sqrt(3))+.5*(endpoint_x(int_count1,1)+endpoint_x(int_count1+1,1));
        i = i+2;
        int_count1 = int_count1 + 1;
    end
    
    for i = 1 : 2*K
        gauss_y(i,1) = sin(1/gauss_x(i,1)); % y vals at Gauss points 
    end
    
    %Compute integral using 2pt Gauss rule
    j = 1;
    while j < 2*K
        int_val(K,1) = int_val(K,1)+(h/2)*(gauss_y(j,1)+gauss_y(j+1,1));
        j= j+2;
    end
    
    err_val(K,1) = abs(int_val(K,1)-0.50283962);
    
    % Check error
    if err_val(K,1)< 10^(-6)
        required_func_evals = K;
        break
    end
end

figure
semilogy(nums,err_val(:,1)) %plots the last approx
title(['Error in Two Point Gauss for K Equal Sized Intervals Up to K=' num2str(K)])
legend({'Integral for K Intervals'},'Location','Northeast')
xlabel('Number of function evaluations') 
ylabel('Error')