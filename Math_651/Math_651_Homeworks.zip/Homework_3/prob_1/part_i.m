%% Problem 1
% Part i: Midpoint Rule

plotpoints = 100000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);
f = sin(1./x);



% How many intervals to stop at
max_intervals = 100000; 
% Store integral for each amount of intervals
int_val = zeros(max_intervals,1);
err_val = zeros(max_intervals,1);
nums = zeros(max_intervals,1);

for i = 1 : max_intervals
    nums(i,1) = i;
end

for K = 1 : max_intervals
    % K is the current number of intervals
    h = (b-a)/K; % Size of interval
    mes_x = zeros(K+1,1); % Extra x so we have K intervals

    mid_x = zeros(K,1);
    mid_y = zeros(K+1,1);

    mes_x(:,1) = linspace(a,b,K+1); % x's at endpoints of intervals
    
    for i = 1 : K
        mid_x(i,1) = .5*(mes_x(i,1)+mes_x(i+1,1)); % Create x midpoints
        mid_y(i,1) = sin(1/mid_x(i,1)); % y vals at midpoints 
    end
    
    % Compute integral for midpoint rule
    int_val(K,1) = sum(h.*mid_y(:,1));
    err_val(K,1) = abs(int_val(K,1)-0.50283962);
    
    % Check error
    if err_val(K,1)< 10^(-6)
        required_func_evals = K;
        break
    end
end

figure
semilogy(nums,err_val(:,1)) %plots the last approx
title(['Error in Midpoint Rule for K Equal Sized Intervals Up to K=' num2str(K)])
legend({'Integral for K Intervals'},'Location','Northeast')
xlabel('Number of function evaluations') 
ylabel('Error')