%% Problem 1
% Part iv: Three Point Gauss Rule

plotpoints = 100000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);
f = sin(1./x);



% How many intervals to stop at
max_intervals = 10000; 
% Store integral for each amount of intervals
int_val = zeros(max_intervals,1);
err_val = zeros(max_intervals,1);
nums = zeros(max_intervals,1);

for i = 1 : max_intervals
    nums(i,1) = 3*i;
end

for K = 1 : max_intervals
    % K is the current number of intervals
    h = (b-a)/K; % Size of interval
    
    endpoint_x = zeros(K+1,1);
    endpoint_x(:,1) = linspace(a,b,K+1);
    
    gauss_x = zeros(3*K,1);
    gauss_y = zeros(3*K,1);
    
    % Compute Gauss points
    i = 1;
    int_count1 = 1;
    while i < 3*K
        gauss_x(i,1) = -(h/2)*(sqrt(3/5))+.5*(endpoint_x(int_count1,1)+endpoint_x(int_count1+1,1));
        gauss_x(i+1,1) = .5*(endpoint_x(int_count1,1)+endpoint_x(int_count1+1,1));
        gauss_x(i+2,1) = (h/2)*(sqrt(3/5))+.5*(endpoint_x(int_count1,1)+endpoint_x(int_count1+1,1));
        i = i+3;
        int_count1 = int_count1 + 1;
    end
    
    for i = 1 : 3*K
        gauss_y(i,1) = sin(1/gauss_x(i,1)); % y vals at Gauss points 
    end
    
    %Compute integral using 2pt Gauss rule
    j = 1;
    while j < 3*K
        int_val(K,1) = int_val(K,1)+(h/2)*((5/9)*gauss_y(j,1)+(8/9)*gauss_y(j+1,1)+(5/9)*gauss_y(j+2,1));
        j= j+3;
    end
    
    err_val(K,1) = abs(int_val(K,1)-0.50283962);
    
    % Check error
    if err_val(K,1)< 10^(-6)
        required_func_evals = K;
        break
    end
end

figure
semilogy(nums,err_val(:,1)) %plots the last approx
title(['Error in Three Point Gauss for K Equal Sized Intervals Up to K=' num2str(K)])
legend({'Integral for K Intervals'},'Location','Northeast')
xlabel('Number of function evaluations') 
ylabel('Error')