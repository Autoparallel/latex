%% Problem 3
% Adaptive Numerical Integration

plotpoints = 100000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);
%f = sin(1./x);

% How many intervals to stop at
max_intervals = 100; 
% Store integral for each amount of intervals
int_val = zeros(max_intervals,1);
err_val = zeros(max_intervals,1);
nums = zeros(max_intervals,1);

N=2; %starting point

for i = 1 : max_intervals
    nums(i,1) = i+1;
end

% Start with two x
mes_x = zeros(2,1);
mes_y = zeros(2,1);
    
mes_x(:,1) = linspace(a,b,2); % x's at endpoints
mes_y(:,1) = sin(1./mes_x(:,1));

for num = 1 : max_intervals
    
    mid_x = zeros(num,1);
    abs_mid_d2f = zeros(num,1);
    eta = zeros(num,1); %error in region
    
    for i = 1 : num
        mid_x(i,1) = .5*(mes_x(i,1)+mes_x(i+1,1)); % Create x midpoints
        abs_mid_d2f(i,1) = abs((2*cos(1/mid_x(i,1))-sin(1/mid_x(i,1)))/(mid_x(i,1)^4)); % y vals at midpoints 
        eta(i,1) = abs_mid_d2f(i,1)*(mes_x(i+1,1)-mes_x(i,1))^3;
    end
    
    % Find index then x value for maximum difference
    [M,I] = max(eta(:,1));
    newx = .5*(mes_x(I,1)+mes_x(I+1,1));
    mes_x(N+1,1) = newx;
    mes_x(:,1) = sort(mes_x(:,1));
    N = N+1;
    for i = 1 : N
        mes_y(i,1) = sin(1/mes_x(i,1));
    end  
    
    %Compute integral using trap rule
    for i = 1 : N-1
        int_val(num,1) = int_val(num,1)+.5*(mes_x(i+1,1)-mes_x(i,1))*(mes_y(i,1)+mes_y(i+1,1));
    end
    
    err_val(num,1) = abs(int_val(num,1)-0.50283962);
    
    % Check error
    if err_val(num,1)< 10^(-6)
        required_func_evals = num;
        break
    end
end

figure
semilogy(nums,err_val(:,1)) %plots the last approx
title(['Error in adaptive integration number of splits =' num2str(num)])
legend({'Integral for K Intervals'},'Location','Northeast')
xlabel('Function Evaluations') 
ylabel('Error')