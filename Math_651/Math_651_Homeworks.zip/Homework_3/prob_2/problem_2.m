%% Problem 2
% Romberg Integration

plotpoints = 100000;
a=0.05;
b=1;
x = linspace(a,b,plotpoints);
f = sin(1./x);

% How many intervals to stop at
max_intervals = 50; 
% Store integral for each amount of intervals
R = zeros(max_intervals,max_intervals);
int_val = zeros(max_intervals,1);
err_val = zeros(max_intervals,1);
err_val_leftcol = zeros(max_intervals,1);
nums = zeros(max_intervals,1);

for i = 1 : max_intervals
    nums(i,1) = 1+2^(i-1);
end

for J = 1 : max_intervals
    h = (b-a)/(2^(J-1)); % interval size at step J
    num_x_points = 1+2^(J-1);
    mes_x = zeros(num_x_points,1);
    mes_y = zeros(num_x_points,1);
    
    mes_x(:,1) = linspace(a,b,num_x_points);
    
    for i = 1 : num_x_points
        mes_y(i,1) = sin(1/mes_x(i,1));
    end
    
    for i = 1 : num_x_points
        if i == 1
            int_val(J,1) = int_val(J,1)+ (h/2)*mes_y(i,1);
        elseif i == num_x_points
            int_val(J,1) = int_val(J,1)+ (h/2)*mes_y(i,1);
        else
            int_val(J,1) = int_val(J,1)+ h*mes_y(i,1);
        end
    end
    
    R(J,1) = int_val(J,1);
    
    if J == 1 
        %do nothing
    else
        for M = 2 : J
                R(J,M) = R(J,M-1)+(1/(4^M-1))*(R(J,M-1)-R(J-1,M-1));
        end
    end
    
    err_val(J,1) = abs(R(J,J)-0.50283962);
    err_val_leftcol(J,1) = abs(int_val(J,1)-0.50283962);
    
    % Check error
    if err_val(J,1)< 10^(-6)
        required_func_evals = J;
        break
    end
    

end

figure
semilogy(nums,err_val(:,1),nums,err_val_leftcol(:,1)) %plots the last approx
title(['Error in Romberg Integration for J-Splits up to J=' num2str(J)])
legend({'R(J,J)','R(J,1)'},'Location','Northeast')
xlabel('Number of function evaluations') 
ylabel('Error')