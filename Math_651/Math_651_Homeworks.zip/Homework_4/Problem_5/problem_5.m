%% Problem 5
% Explicit Euler Method for the Rocket

d_0 = 6371000;

runs = 20;
err = zeros(runs,1);
step_size = zeros(runs,1);

final_point = zeros(runs,1);

for n = 1 : runs
    Delta_t = 2^(-n+3);
    step_size(n,1) = Delta_t;
    a = 0;
    b = 36000;
    num_steps = 1+(b-a)/Delta_t;
    t_vals = linspace(a,b,1+(b-a)/Delta_t);
    approx_v = zeros(num_steps,1);
    approx_d = zeros(num_steps,1);
    
    %Initialize approx_x
    approx_d(1,1) = d_0;
    approx_v(1,1) = 0; % at rest from beginning
    
    %Solve the equation for v and d
    curr_t = a; %tells current spot in t
    for i = 2 : num_steps
        % Know d based on previous v
        approx_d(i,1) = approx_d(i-1,1) + Delta_t*(approx_v(i-1,1));
        if curr_t < 600
            m = 1-0.9*curr_t/600;
            F = 12-(6371000)^2*10*m/(approx_d(i-1,1)^2);
            
            approx_v(i,1) = approx_v(i-1,1) + Delta_t*F/m;
            
            curr_t = curr_t + Delta_t;
        else
            m = 0.1;
            F = 0 -(6371000)^2*10*m/(approx_d(i-1,1)^2);
            
            approx_v(i,1) = approx_v(i-1,1) + Delta_t*F/m;
            
            curr_t = curr_t + Delta_t;
        end
    end
    final_point(n,1) = approx_d(num_steps,1);
    if n == 1
        % do nothing
    elseif final_point(n,1)-final_point(n-1,1)<1000
        final_point(n,1)-final_point(n-1,1)
        break
    end
end

plot(t_vals(1,:),approx_d(:,1));
title(['Trajectory of Rocket'])
legend({'d(t)'},'Location','Northeast')
xlabel('t') 
ylabel('d')