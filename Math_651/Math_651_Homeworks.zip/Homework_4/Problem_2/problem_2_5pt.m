%% Problem 2
% 5 Point Stencil Derivative

total_h = 1000;

f = @(x) exp(x);
h_vals = zeros(total_h,1);
D_h = zeros(total_h,1);
err = zeros(total_h,1);

for N = 1 : total_h 
   h = 1/N;
   h_vals(N,1) = h;
   D_h(N,1) = (-f(2*h)+8*f(h)-8*f(-h)+f(-2*h))/(12*h);
   err(N,1) = abs(D_h(N,1)-1);
end

figure
loglog(h_vals(:,1),err(:,1),h_vals(:,1),h_vals(:,1).^4) %
title(['Derivative Values for 5 Point Stencil'])
legend({'5 Point Stencil Derivative', 'O(h^4)'},'Location','Northeast')
xlabel('h') 
ylabel('Approximate Derivative Value')