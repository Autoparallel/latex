%% Problem 2
% 3 Point Stencil Derivative

total_h = 1000;

f = @(x) exp(x);
h_vals = zeros(total_h,1);
D_h = zeros(total_h,1);
err = zeros(total_h,1);

for N = 1 : total_h 
   h = 1/N;
   h_vals(N,1) = h;
   D_h(N,1) = (f(h)+f(-h)-2*f(0))/(h^2);
   err(N,1) = abs(D_h(N,1)-1);
end

figure
loglog(h_vals(:,1),err(:,1),h_vals(:,1),h_vals(:,1).^2) %
title(['Derivative Values for 3 Point Stencil'])
legend({'3 Point Stencil Derivative', 'O(h^2)'},'Location','Northeast')
xlabel('h') 
ylabel('Approximate Derivative Value')