%% Problem 1
% Monte Carlo Integration

a = 0.05;
b = 1;

plotpoints = 1000000;
x = linspace(a,b,plotpoints);
f = sin(1./x);

max_points = 1000;
int_approx = zeros(max_points,1);

err_val = zeros(max_points,1);
nums = zeros(max_points,1);

for i = 1 : max_points
    nums(i,1) = i;
end

for N = 1 : max_points
    rand_x_points = zeros(N,1);
    rand_y_points = zeros(N,1);

    h = (b-a);

    true_int_value = 0.50283962;

    for i = 1 : N
        rand_x_points(i,1) = 0.05+0.95*rand;
        rand_y_points(i,1) = sin(1/rand_x_points(i,1));
    end

    int_approx(N,1) = (h/N)*sum(rand_y_points(:,1));
    
    err_val(N,1) = abs(int_approx(N,1)-0.50283962);
    
%     % Check error
%     if err_val(N,1)< 10^(-6)
%         required_func_evals = N;
%         break
%     end
end

figure
semilogy(nums,err_val(:,1)) %plots the last approx
title(['Error in Monte Carlo Integration N=' num2str(N)])
legend({'Monte Carlo Integral'},'Location','Northeast')
xlabel('Number of function evaluations') 
ylabel('Error')