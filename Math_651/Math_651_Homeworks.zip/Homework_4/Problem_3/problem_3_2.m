%% Problem 3
% Part  2: Approximate Derivatives

x_0 = -0.5;

total_h_vals = 10000;
err_h = zeros(total_h_vals,1);

h_vals = zeros(total_h_vals,1);
for i = 1 : total_h_vals
    h_vals(i,1) = 1/i;
end

for N = 1 : total_h_vals
    h = 1/N;

    f = @(x) x*exp(x)-1;

    df = @(x) (1/(2*h))*(f(x+h)-f(x-h));
    d2f = @(x) (1/(h^2))*(f(x+h)-2*f(x)+f(x-h));

    total_runs = 10; % Number of iterates for NM
    iterations = zeros(total_runs,1);
    for k = 1 : total_runs
        iterations(k,1) = k;
    end

    x_star = zeros(total_runs,1);
    diffs_x_star = zeros(total_runs,1); %log_10 of differences to see if it hits -6
    for K = 1 : total_runs

        x_star(1,1) = x_0; % initial guess

        for k = 1 : total_runs
            x_star(k+1,1) = x_star(k,1)-df(x_star(k,1))/d2f(x_star(k,1));
        end

    end
   	err_h(N,1) = abs(x_star(K,1)+1);
end

loglog(h_vals(:,1),err_h(:,1));
title(['Error in Newtons Method as a Function of h'])
legend({'Newton Approximation'},'Location','Northeast')
xlabel('Size of h') 
ylabel('Error')
