%% Problem 3
% Part  1: Exact Derivatives

x_0 = -0.5;

f = @(x) x*exp(x)-1;
df = @(x) exp(x)*(x+1);
d2f = @(x) exp(x)*(x+2);

total_runs = 20; % Number of iterates for NM
iterations = zeros(total_runs,1);
for k = 1 : total_runs
    iterations(k,1) = k;
end

x_star = zeros(total_runs,1);
diffs_x_star = zeros(total_runs,1); %log_10 of differences to see if it hits -6
for K = 1 : total_runs

    x_star(1,1) = x_0; % initial guess

    for k = 1 : total_runs-1
        x_star(k+1,1) = x_star(k,1)-df(x_star(k,1))/d2f(x_star(k,1));
    end

    % Compute differences between approximate x_star values and true value
    diffs_x_star(K,1) = abs(x_star(K,1)+1);
    if diffs_x_star(K,1)< 10^(-6)
        break
    end
end

semilogy(iterations(:,1),diffs_x_star(:,1));
title(['Error in Newtons Method With Exact Derivatives K=' num2str(K)])
legend({'Newton Approximation'},'Location','Northeast')
xlabel('Number of function evaluations') 
ylabel('Error')
