%% Problem 4
% Implicit Euler Method

f = @(x) .5*x;
true_x_4 = exp(.5*4);
x_0 = 1;

err3 = zeros(7,1);
step_size = zeros(7,1);

x_newton_step = zeros(10,1);

for n = 1 : 6 %should be 6
    Delta_t = 2^(-n+1);
    step_size(n,1) = Delta_t;
    a = 0;
    b = 4;
    num_steps = 1+(b-a)/Delta_t;
    t_vals = linspace(a,b,1+(b-a)/Delta_t);
    approx_x = zeros(num_steps,1);
    
    %Initialize approx_x
    approx_x(1,1) = x_0;
    
    %Solve the equation
    for i = 2 : num_steps
        %Newton's method to solve the implicit equation
        x_newton_step(1,1) = approx_x(i-1,1);
        for j = 2 : 10
            numerator = -x_newton_step(j-1,1) + approx_x(i-1,1)+...
                Delta_t*x_newton_step(j-1,1)/2;
            denominator = -1 + Delta_t/2;
            x_newton_step(j,1) = x_newton_step(j-1,1)-numerator/denominator;
%             if x_newton_step(j,1) < 10^(-6)
%                 approx_x(i,1) = x_newton_step(j,1);
%                 break
%             end
        end
        approx_x(i,1) = x_newton_step(10,1);
    end
    err3(n,1) = abs(approx_x(num_steps,1)-true_x_4);
end

loglog(step_size(:,1),err3(:,1));
title(['Error in Implicit Euler Method'])
legend({'Error in x(4)'},'Location','Northeast')
xlabel('Step size') 
ylabel('Error')