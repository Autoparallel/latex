

%Program 3c: Computing the Lyapunov exponent.
clear;
r=4;
x=0.1;xo=x;
itermax=49999;
for n=1:itermax
xn=r*xo*(1-xo);
x=[x xn];
xo=xn;
end
Liap_exp=vpa(sum(log(abs(r*(1-2*x))))/itermax,6)

