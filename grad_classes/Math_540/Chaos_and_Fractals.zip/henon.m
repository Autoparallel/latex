% Make points in the plane
numpoints = 10000;
x = zeros(numpoints,1);
y = zeros(numpoints,1);

for i = 1 : numpoints
    x(i) = 2*(rand-.5);
    y(i) = 2*(rand-.5);
end

% Henon Mapping
a = 1.4;
b = 0.3;
iterations = 99;
x_it = x;
y_it = y;
x_temp = zeros(numpoints,1);

for i = 1 : iterations
    for j = 1 : numpoints
        % Folding
        y_it(j) = 1-a*x_it(j)^2+y_it(j);
        % Contraction
        x_it(j) = b * x_it(j);

        % Reflection
        x_temp(j) = x_it(j);
        x_it(j) = y_it(j);
        y_it(j) = x_temp(j);
    end
end

figure
subplot(2,2,1);
scatter(x_it,y_it,.5);
axis([-2 2 -2 2])
pbaspect([1 1 1])

% Folding then plot
for i = 1 : numpoints
    y_it(i) = 1-a*x_it(i)^2+y_it(i);
end
subplot(2,2,2);
scatter(x_it,y_it,.5)
axis([-2 2 -2 2])
pbaspect([1 1 1])

% Contraction then plot
for i = 1 : numpoints
    x_it(i) = b * x_it(i);
end
subplot(2,2,3);
scatter(x_it,y_it,.5)
axis([-2 2 -2 2])
pbaspect([1 1 1])

% Reflection then plot
for i = 1 : numpoints
    x_temp(i) = x_it(i);
    x_it(i) = y_it(i);
    y_it(i) = x_temp(i);
end
subplot(2,2,4);
scatter(x_it,y_it,.5)
axis([-2 2 -2 2])
pbaspect([1 1 1])

