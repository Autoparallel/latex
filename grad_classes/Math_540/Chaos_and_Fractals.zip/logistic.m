% BEGIN Logistic map iteration
% Make points on the line
numpoints = 100000;
x = zeros(numpoints,1);

for i = 1 : numpoints
    x(i) = rand;
end

% Logistic mapping
iterations = 1000;
x_it = x;
y_it = x_it;

r = .5;
figure
for i = 1 : iterations
    for j = 1 : numpoints
        y_it(j) = r*x_it(j)*(1-x_it(j));
    end
    x_it = y_it;
end
subplot(2,2,1);
scatter(x,y_it,.5);
axis([-.01 1.01 -.01 1])
pbaspect([1 1 1])

r= 1.5;
x_it = x; % reinitialize x values
for i = 1 : iterations
    for j = 1 : numpoints
        y_it(j) = r*x_it(j)*(1-x_it(j));
    end
    x_it = y_it;
end
subplot(2,2,2);
scatter(x,y_it,.5);
axis([-.01 1.01 -.01 1])
pbaspect([1 1 1])

r= 3.5;
x_it = x; % reinitialize x values
for i = 1 : iterations
    for j = 1 : numpoints
        y_it(j) = r*x_it(j)*(1-x_it(j));
    end
    x_it = y_it;
end
subplot(2,2,3);
scatter(x,y_it,.5);
axis([-.01 1.01 -.01 1])
pbaspect([1 1 1])

r= 3.8;
x_it = x; % reinitialize x values
for i = 1 : iterations
    for j = 1 : numpoints
        y_it(j) = r*x_it(j)*(1-x_it(j));
    end
    x_it = y_it;
end
subplot(2,2,4);
scatter(x,y_it,.5);
axis([-.01 1.01 -.01 1])
pbaspect([1 1 1])
% END Logistic map iteration
