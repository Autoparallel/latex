% Code Courtesy of Lynch ``Dynamical Systems with Application using Matlab"
% BEGIN Plotting logistic map bifurcation
clear
itermax=100;
finalits=30;finits=itermax-(finalits-1);
for r=0:0.005:4
x=0.4;
xo=x;
for n=2:itermax
xn=r*xo*(1-xo);
x=[x xn];
xo=xn;
end
plot(r*ones(finalits),x(finits:itermax),'.','MarkerSize',1)
hold on
end
fsize=15;
set(gca,'XTick',0:1:4,'FontSize',fsize)
set(gca,'YTick',0:0.2:1)
xlabel('r','FontSize',fsize)
ylabel('\itx','FontSize',fsize)
title('Logistic Map Bifurcation');
hold off
% END Plotting logistic map bifurcation