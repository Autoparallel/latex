
% BEGIN Plotting Logistic Windows
n=50; % Number of points
nvec=(0:1:n);
r=3.8; % Parameter value
x=(1/n:1/n:1);

for ii=1:n
    x(ii+1)=r*x(ii)*(1-x(ii));
end
plot(nvec,x)
 
title(['Discrete Logistic Map with ' , num2str(n),' Interations and r= '
,num2str(r)])
xlabel('Number of Interations (n)')
ylabel('x_n')
% END Plotting Logistic Windows


% Code Courtesy of Lynch ``Dynamical Systems with Application using Matlab"
% BEGIN Plotting logistic map bifurcation
clear
itermax=100;
finalits=30;finits=itermax-(finalits-1);
for r=0:0.005:4
x=0.4;
xo=x;
for n=2:itermax
xn=r*xo*(1-xo);
x=[x xn];
xo=xn;
end
plot(r*ones(finalits),x(finits:itermax),'.','MarkerSize',1)
hold on
end
fsize=15;
set(gca,'XTick',0:1:4,'FontSize',fsize)
set(gca,'YTick',0:0.2:1)
xlabel('r','FontSize',fsize)
ylabel('\itx','FontSize',fsize)
title('Logistic Map Bifurcation');
hold off
% END Plotting logistic map bifurcation

% Code Courtesy of Lynch ``Dynamical Systems with Application using Matlab"
% BEGIN Program 3c: Computing the Lyapunov exponent
clear;
r=4;
x=0.1;xo=x;
itermax=49999;
for n=1:itermax
xn=r*xo*(1-xo);
x=[x xn];
xo=xn;
end
Liap_exp=vpa(sum(log(abs(r*(1-2*x))))/itermax,6)
% END Program 3c: Computing the Lyapunov exponent


%Code Courtesy of Lynch ``Dynamical Systems with Application using Matlab"
% BEGIN Program 6a: Plotting the Koch curve
clear
k=5;
mmax=4^k;
x=zeros(1,mmax);y=zeros(1,mmax);segment=zeros(1,mmax);
h=3^(-k);
x(1)=0;y(1)=0;
angle(1)=0;angle(2)=pi/3;angle(3)=-pi/3;angle(4)=0;
for a=1:mmax
    m=a-1;ang=0;
    for b=1:k
        segment(b)=mod(m,4);
        m=floor(m/4);
        r=segment(b)+1;
        ang=ang+angle(r);
    end
    x(a+1)=x(a)+h*cos(ang);
    y(a+1)=y(a)+h*sin(ang);
end
plot(x,y,'b');
title(['Koch Curve at stage ' , num2str(k)])
axis equal
% END Program 6a: Plotting the Koch curve


% BEGIN Program 3g: Lyapunov exponents of the Henon map
%Code Courtesy of Lynch ``Dynamical Systems with Application using Matlab"
itermax=500;
a=1.3;b=0.4;x=0;y=0;
vec1=[1;0];vec2=[0;1];
for i=1:itermax
x1=1-a*x^2+y;y1=b*x;
x=x1;y=y1;
J=[-2*a*x 1;b 0];
vec1=J*vec1;
vec2=J*vec2;
dotprod1=dot(vec1,vec1);
dotprod2=dot(vec1,vec2);
vec2=vec2-(dotprod2/dotprod1)*vec1;
lengthv1=sqrt(dotprod1);
area=vec1(1)*vec2(2)-vec1(2)*vec2(1);
h1=log(lengthv1)/i;
h2=log(area)/i-h1;
end
fprintf('h1= %12.10f\n',h1)
fprintf('h2= %12.10f\n',h2)
% END Program 3g: Lyapnuov exponents of the Henon map
