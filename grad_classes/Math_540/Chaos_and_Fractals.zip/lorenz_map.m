% BEGIN Lorenz map iteration
% Make points in space
numpoints = 1000000;
x = zeros(numpoints,1);
y = zeros(numpoints,1);
z = zeros(numpoints,1);

for i = 1 : numpoints
    x(i) = 2*(rand-.5);
    y(i) = 2*(rand-.5);
    z(i) = 2*(rand-.5);
end

% Parameter values
s = 10;
b = 8/3;
p = 28;
delta_t = .0005;

% Lorenz Map
x_it = x; %initialize the variables
y_it = y;
z_it = z;

iterations = 2801;

figure
for i = 1 : iterations
    if mod(i-1,400) == 0
        num = floor(i/400)+1;
        subplot(4,2,num);
        scatter3(x_it,y_it,z_it,.5);
        pbaspect([1 1 1])
        num %show step
    end
    for j = 1 : numpoints
         x_it(j) = x_it(j) + s*(-x_it(j)+y_it(j))*delta_t;
         y_it(j) = y_it(j) + (p*x_it(j)-x_it(j)*z_it(j)-y_it(j))*delta_t;
         z_it(j) = z_it(j) + (x_it(j)*y_it(j)-b*z_it(j))*delta_t;
    end
end
% END Lorenz map iteration