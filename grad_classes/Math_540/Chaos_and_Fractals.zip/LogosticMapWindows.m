

n=50;
nvec=(0:1:n);
r=3.8;
x=(1/n:1/n:1);
for ii=1:n
    x(ii+1)=r*x(ii)*(1-x(ii));
end
plot(nvec,x)

title(['Discrete Logistic Map with ' , num2str(n),' Interations and r= ',num2str(r)])
xlabel('Number of Interations (n)')
ylabel('x_n')